# Projeto AWS S3 + SNS: Compartilhamento de Arquivos com Notificação por E-mail

Este projeto simula o ambiente de uma cafeteria que precisa compartilhar imagens com uma empresa de mídia externa, utilizando o Amazon S3 para armazenamento e o SNS para envio de notificações por e-mail sempre que arquivos forem alterados.

## Funcionalidades
- Criação de bucket no Amazon S3
- Upload e remoção de arquivos via AWS CLI
- Permissões gerenciadas com IAM para acesso externo seguro
- Notificações por e-mail usando Amazon SNS

## Serviços Utilizados
- Amazon S3
- Amazon SNS
- AWS CLI
- Amazon IAM
- EC2 Instance Connect

## Etapas do Projeto

### 1. Criar o Bucket
```bash
aws s3 mb s3://cafe-exemplo123 --region 'us-west-2'
```

### 2. Sincronizar imagens
```bash
aws s3 sync ~/initial-images/ s3://cafe-exemplo123/images
```

### 3. Visualizar conteúdo
```bash
aws s3 ls s3://cafe-exemplo123/images/ --human-readable --summarize
```

### 4. Criar tópico SNS
- Nome: `s3NotificationTopic`
- Protocolo: Email

### 5. Configuração de notificação (exemplo JSON)
```json
{
  "TopicConfigurations": [
    {
      "TopicArn": "arn:aws:sns:us-west-2:123456789012:s3NotificationTopic",
      "Events": ["s3:ObjectCreated:*", "s3:ObjectRemoved:*"],
      "Filter": {
        "Key": {
          "FilterRules": [
            { "Name": "prefix", "Value": "images/" }
          ]
        }
      }
    }
  ]
}
```

### 6. Testes realizados
- ✅ Upload autorizado por usuário externo (mediacouser)
- ✅ Exclusão de objeto via AWS CLI
- ✅ Falha ao tentar alterar ACL (não autorizado)
- ✅ Recebimento de e-mails do SNS após eventos no bucket

---

## Licença
Projeto educativo baseado em laboratório oficial da AWS Academy.
